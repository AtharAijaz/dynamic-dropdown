<!DOCTYPE html>
<html>
<head>
  <title>edit</title>
</head>
  <body>
    <?php echo validation_errors(); ?>
    <!--<form method="post" action="/codeigniter/categories/update">-->
    <form method="post" action="<?php echo base_url('products/update/'.$product->id);?>">
      <table> 
        <tr>
        <th>Category id</th>
        <!-- <td><input type="text" name="category_id" class="form-control" value="<?php echo $product->category_id; ?>"></td> -->
        <td class="form-group"> 
          <select class="form_control" name="categories" id='categories'>
            <option value="">< not selected ></option>
            <?php
            foreach($categories as $row):?>
            <option value="<?php echo $row->id;?>"><?php echo $row->name;?></option>
            <?php endforeach;?>
          </select>
        </td>
        </tr>
        <tr>
          <th>Subcategory Name</th>
          <!-- <td><input type="text" name="subcategories" class="form-control" value="<?php echo $product->subcategory_id; ?>"></td>  -->
          <td>
            <select class="form-control" name="subcategories" >
                          <option value="">No Selected</option>
            </select>
          </td>         
        </tr>
        <tr>
          <th>Product Name</th>
          <td><input type="text" name="name" class="form-control" value="<?php echo $product->name; ?>"></td>
        </tr>
        <tr>
          <th></th>
          <td>
          <input type="submit" name="Submit" value="Store">
          </td>
        </tr>
      </table>
      
    </form>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
    <script type="text/javascript">
      $(document).ready(function(){
          //call function get data edit
          get_data_edit();
          alert("1");
          $('.categories').change(function(){ 
            var id=$(this).val();
            var id = "<?php echo $id;?>";
            $.ajax({
                url : "<?php echo site_url('Products/fetch_subcategory');?>",
                method : "POST",
                data : {id: id},
                async : true,
                dataType : 'json',
                success: function(data){
                  $('select[name="subcategories"]').empty();

                  $.each(data, function(key, value) {
                      if(id==value.id){
                          $('select[name="subcategories"]').append('<option value="'+ value.id +'" selected>'+ value.name +'</option>').trigger('change');
                      }else{
                          $('select[name="subcategories"]').append('<option value="'+ value.id +'">'+ value.name +'</option>');
                      }
                  });

                }
            });
            return false;
          });

/*

            function get_data_edit(){
                var id = $('[name="id"]').val();
                $.ajax({
                    url : "<?php echo site_url('product/get_data_edit');?>",
                    method : "POST",
                    data :{id :id},
                    async : true,
                    dataType : 'json',
                    success : function(data){
                        $.foreach(data, function(i, item){
                            //$('[name="product_name"]').val(data[i].name);
                            $('[name="categories"]').val(data[i].category_id).trigger('change');
                            $('[name="subcategories"]').val(data[i].subcategory_id).trigger('change');
                            //$('[name="product_price"]').val(data[i].product_price);
                        });
                    }
 
                });
            }
             
        });

*/

$(document).ready(function(){
    $('#subcategories').change(function(){ 
      var id=$(this).val();
      $.ajax({
          url : "<?php echo site_url('Products/fetch_subcategory');?>",
          method : "POST",
          data : {id:id},
          async : true,
          dataType : 'json',
          success: function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
                html += '<option value='+data[i].id+'>'+data[i].name+'</option>';
            }
          $('#subcategories').html(html);
      }
      });
      return false;
    }); 
  });



    </script>       
  </body>
</html>






