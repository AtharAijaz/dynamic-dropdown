<!DOCTYPE html>
<html>
  <head>
    <title>Product daetail</title>
    <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
  </head>
  <body>
      <table class="table table-striped" id="mytable" style="font-size: 14px;">
        <tr>
          <td>product id:</td>
          <td><?php echo $product['id']; ?></td> 
        </tr>                     
        <tr>
          <td>category id:</td>
          <td><?php echo $product['category_id']; ?></td> 
        </tr>
        <tr>
          <td>Subcategory id:</td>      
          <td><?php echo $product['subcategory_id']; ?></td>
        </tr>
        <tr> 
          <td>Product Name:</td>   
          <td><?php echo $product['name']; ?></td>    
        </tr>
      </table>
      <td></td>
      <a href="<?php echo base_url().'products/index/';?>" class="btn btn-sm btn-primary">Back</a>
      <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
      <script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
      <script type="text/javascript" src="<?php echo base_url().'assets/js/datatables.js'?>"></script>
      <script type="text/javascript">
          $(document).ready(function(){
              $('#mytable').DataTable();
          });
      </script>
  </body>
</html>
