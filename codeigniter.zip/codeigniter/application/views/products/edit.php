<!DOCTYPE html>
<html>
<head>
  <title>Insert form</title>
  <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
</head>
  <body>
    <?php echo validation_errors(); ?>
    <!-- <?php echo form_open('products/edit'); ?> -->
    <form method="post" action="<?php echo base_url('products/update');?>">
      <table>
        <tr>
          <td><br></td>
        </tr>                        
      <!-- Categories -->
        <tr>
          <td>category</td>
          <td class="form-group"> 
            <select class="form_control" name="category_id" id='category_id'>
            <!-- <option value="">category</option> -->
              <?php
              foreach($categories as $row):?>
              <option value="<?php echo $row['id'];?>"<?php echo($row['id'])==($result['category_id'])? 'selected="selected"':''?>><?=$row['name']?></option> 
              <?php endforeach;?>
            </select>
          </td>
        </tr>
        <tr>
          <td><br></td>
        </tr>

        <tr>
          <td>Subcategory</td>
          <td class="form-group">
            <select class="form-control" name="subcategory_id" id="subcategory_id">
              <!-- <?php foreach ($categories as $category): ?> -->
                <!-- <?php if (($category['id'])==($result['category_id'])): ?> -->
                  <?php foreach ($subcategories as $subcategory): ?>
                    <option value="<?= $subcategory['id']?>" <?php echo($subcategory['id'])==($result['subcategory_id'])? 'selected="selected"':''?> ><?=$subcategory['name']?></option>
                 <?php endforeach ?>
                <!-- <?php endif ?> -->
              <!-- <?php endforeach ?> -->
            </select>
          </td>
        </tr>

        <tr>
          <td><br></td>
        </tr>
        <tr> 
          <td>Enter Product Name</td>
          <td>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo $result['name']?>">    
          </td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <th></th>
           <input type="hidden" name="id" id="id" value="<?php echo $id?>">
          <td><button class="btn btn-success" type="submit">Update Product</button></td>
          <!-- <button class="btn btn-success" type="submit">Save Product</button> -->
        </tr>
      </table>
    </form>
  </body>
</html>

<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#category_id').click(function(){ 
      var id=$(this).val();
      $.ajax({
          url : "<?php echo site_url('Products/fetch_subcategory');?>",
          method : "POST",
          data : {id:id},
          async : true,
          dataType : 'json',
          success: function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
                html += '<option value='+data[i].id+'>'+data[i].name+'</option>';
            }
          $('#subcategory_id').html(html);
         // alert("1");
      }
      });
      return false;
    });

var input = "category_id";
}); 
</script>


