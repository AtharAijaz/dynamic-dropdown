<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <link href="<?php echo base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url().'assets/css/datatables.css'?>" rel="stylesheet" type="text/css">
    <script type="text/javascript">
    function show_confirm(action, gotoid) {
      if(action=="edit")
        var conf=confirm("Do you really want to edit?");
      else
        var conf=confirm("Do you really want to delete?");
      if (conf==true){
        window.location="<?php echo base_url();?>products/"+action+"/"+gotoid;
      }
    }
  </script>
</head>
<body>
    <div class="container">
 
      <div class="row justify-content-md-center">
        <div class="col col-lg-8">
            <h3>Product List</h3>
            <?php echo $this->session->flashdata('msg');?>
           <!--  <a href="<?php echo site_url('product/add_new');?>" class="btn btn-success btn-sm">Add New Product</a><hr/> -->
            <!-- <a href=<?php echo base_url().'products/fetch_category/'.$row->id;?> class="btn btn-success btn-sm">Add New Product</a> -->
            <table class="table table-striped" id="mytable" style="font-size: 14px;">
              <thead>
                  <tr>
                    <th scope="col">S.no</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Subcategory</th>
                    <th scope="col" colspan="2">Action</th>
                  </tr>
              </thead>
              <tbody>
                <?php $no=0;
                foreach ($product_list->result()as $row): 
                $no++;?>
                <tr>
                  <!-- <td><?php echo $row->id; ?></td> -->
                  <td><?php echo $no; ?></td>
                  <td><?php echo $row->product; ?></td>
                  <td><?php echo $row->category; ?></td>
                  <td><?php echo $row->subcategory; ?></td>
                  <td>
                      <a href="<?php echo base_url().'products/edit/'.$row->id; ?>" class="btn btn-sm btn-info">Edit</a>
                      <a href="<?php echo base_url().'products/view/'.$row->id; ?>" class="btn btn-sm btn-primary">View</a>
                     <!--  <a href="#" onClick="show_confirm('delete',<?php echo $row->id;?>)">Delete</a> -->
                     <a href="#" onClick="show_confirm('delete',<?php echo $row->id;?>)" class="btn btn-sm btn-danger">Delete</a>
                  </td>
                </tr>
                <?php endforeach;?>
                   <a href="<?php echo base_url().'products/fetch_category/'.$row->id;?>" class="btn btn-success btn-sm">Add New Product</a>
              </tbody>
            </table>
        </div>
      </div>
 
    </div>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/datatables.js'?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#mytable').DataTable();
        });


    </script>
</body>
</html>










