<!DOCTYPE html>
<html>
<head>
  <title>Insert form</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
  <body>
    <?php echo validation_errors(); ?>
    <form method="post" action="<?php echo base_url('products/insert_products');?>">
      <table>
        <tr>
          <td><br></td>
        </tr>
      <!-- Categories -->
        <tr>
          <td>category</td>
          <td class="form-group"> 
            <select class="form_control" name="categories" id='categories'>
              <option value="none">-- Select category --</option>
              <?php
              foreach($categories as $row):?>
              <option value="<?php echo $row->id;?>"><?php echo $row->name;?></option>
              <?php endforeach;?>
            </select>
          </td>
        </tr>

        <tr>
          <td><br></td>
        </tr>

        <tr>
          <td>Subcategory</td>
          <td>
            <select class="form-control" name="subcategories" id="subcategories">
              <option value="">-- Select subcategories --</option>
           </select>
          </td>
        </tr>

        <tr>
          <td><br></td>
        </tr>
        <tr> 
          <th>Enter Product Name</th>
          <td><input type="text" class="form_control" name="name" placeholder="Product Name"  ></td>
        </tr>
        <tr>
          <td><br></td>
        </tr>
        <tr>
          <th></th>
          <!-- <td><input type="submit" name="Submit" value="Store"></td> -->
          <td><button class="btn btn-success" type="submit">Save Product</button></td>
          <!-- <button class="btn btn-success" type="submit">Save Product</button> -->
        </tr>
    </table>
  </form>
</body>
</html>

<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-3.3.1.js'?>"></script>
<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#categories').change(function(){ 
      var id=$(this).val();
      $.ajax({
          url : "<?php echo site_url('Products/fetch_subcategory');?>",
          method : "POST",
          data : {id:id},
          async : true,
          dataType : 'json',
          success: function(data){
            var html = '';
            var i;
            for(i=0; i<data.length; i++){
                html += '<option value='+data[i].id+'>'+data[i].name+'</option>';
            }
          $('#subcategories').html(html);
      }
      });
      return false;
    }); 
  });
</script>