<body>
  <!-- navbar -->
  <div id="navbar" >
    <ul class="nav nav-pills nav-stacked">
      <li role="presentation"><a href="<?php echo base_url() ?>electronics/create">Create</a></li>
      <li role="presentation"><a href="<?php echo base_url() ?>electronics/read">Read</a></li>
      <li role="presentation"><a href="<?php echo base_url() ?>electronics/archive ">Archive</a></li>
    </ul>
  </div>
  <div class="container">
    
  </div>
</body>
