    <!DOCTYPE html>  
    <html>  
    <head>  
        <title>Hello World</title>  
    </head>  
    <body>  
      
     <p>Hello World!!</p>  
     <h1><?php echo $row;?></h1>
     </body>  
    </html>  