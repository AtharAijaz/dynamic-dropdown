<table>
<tbody>
  <tr>
    <?php echo form_label('Categories :'); ?> <br />
<?php echo form_data(array('id' => 'name', 'name' => 'name')); ?><br />
  
</tbody>
</table>