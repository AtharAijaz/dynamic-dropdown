<?php
class Products extends CI_Controller{
  public function __construct(){
    parent::__construct();
    $this->load->helper('url');
    $this->load->model('Product_model'); 

  }

  public function index(){
    $data['product_list'] = $this->Product_model->get_products();
    $this->load->view('products/show_products', $data);
  }

   public function fetch_category(){
    //print_r($_POST); die;
    $data['categories'] = $this->Product_model->fetch_category()->result();
    //print_r($data); die;
    $this->load->view('products/insert', $data);
  }

  public function fetch_subcategory(){
    $id = $this->input->post('id',TRUE);
    $data = $this->Product_model->fetch_subcategory($id)->result();// print_r($data);die;
    echo json_encode($data); 
  }

  public function insert_products(){
    //echo"<prev>";print_r($_POST); die;
    $this->form_validation->set_rules('categories','categories','required|callback_validate_dropdown');
    $this->form_validation->set_rules('name','name','required|is_unique[products.name]',
      array('required'=>'you must provide product %s',
            'is_unique'=>'product exists'));
    if($this->form_validation->run()==FALSE){
      $this->load->view('products/insert');
    }else{
      //print_r($this->input->post('subcategories')); die;
      $data['name']           = $this->input->post('name');
      $data['category_id']    = $this->input->post('categories');
      $data['subcategory_id'] = $this->input->post('subcategories');
      $res = $this->Product_model->insert_product_to_table($data);
      redirect(base_url('products'));
    }

  }

  function validate_dropdown($data){
    if ($data=="none") {
      $this->form_validation->set_message('validate_dropdown', 'Please Select Your Category.');
      return FALSE;
    }
    else{
      return TRUE;

    }
  }

   public function edit(){
    $id = $this->uri->segment(3);
    $get_data = $this->Product_model->get_product_by_id($id);
    if($get_data->num_rows() > 0){
      $data['result'] = $get_data->row_array();       //echo "<pre>";print_r($data);die;
    }
    $data['id']            = $id;
    $data['name']          = $this->input->post('name');
    $data['categories']    = $this->Product_model->fetch_category()-> result_array();
    $data['subcategories'] = $this->Product_model->fetch_subcategory($data['result']['category_id'])->result_array(); // echo "<pre>";print_r($data);die;
    $this->load->view('products/edit',$data);
  }

  public function update(){
    //$id=$this->input->post();
    $data['id']=$this->input->post('id');
    $get_data = $this->Product_model->get_product_by_id($data['id']);
    if($get_data->num_rows() > 0){
       $data['result'] = $get_data->row_array();
    }
    $data['categories']    = $this->Product_model->fetch_category()-> result_array();
    $data['subcategories'] = $this->Product_model->fetch_subcategory($data['result']['category_id'])->result_array(); // echo
    $this->form_validation->set_rules('category_id','category_id','required');
    $this->form_validation->set_rules('subcategory_id','subcategory_id','required');
    $this->form_validation->set_rules('name', 'name', 'required|is_unique[products.name]',
                        array('required' => 'You must provide a %s.',
                              'is_unique'=>'%s exists'));

    if ($this->form_validation->run() == FALSE) {
      
     //echo "<pre>";print_r($data);die;
      //redirect(base_url('products'));
      //$this->edit($data['id']);
      //$this->edit($data);
      $this->load->view('products/edit',$data);      
      //echo "<pre>";print_r($data);die;
    }
    else{
      $data['id']             = $this->input->post('id');
      $data['name']           = $this->input->post('name');
      $data['category_id']    = $this->input->post('category_id');
      $data['subcategory_id'] = $this->input->post('subcategory_id');
     // print_r($data);die;
      $res = $this->Product_model->update_product($data);
      redirect(base_url('products'));
    }
  }

  public function delete($id){
    $this->Product_model->delete_product($id);
    $this->index();
  }

  public function view($id){
    $data['product'] = $this->Product_model->view_product($id)->row_array(); //echo "<pre>";print_r($data);die;
    $this->load->view('products/view',$data);

  }


}
