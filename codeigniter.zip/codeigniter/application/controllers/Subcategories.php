<?php  
class Subcategories extends CI_Controller{
  public function __construct(){
    parent::__construct();
    $this->load->helper('url');
    $this->load->model('Subcategory_model');
    $this->load->library('form_validation'); 
  }

  public function index(){
    $data['subcategory_list'] = $this->Subcategory_model->get_subcategories();
    $this->load->view('subcategories/show_subcategories', $data);
  }

  public function add_form(){
    //print_r($_POST); die;
    $data['categories'] = $this->Subcategory_model->get_all_category();//print_r($data); die;
    $this->load->view('subcategories/insert', $data);
  }
  
  public function insert_subcategories(){
    $this->form_validation->set_rules('category_id','category_id','required|callback_validate_dropdown');
    $this->form_validation->set_rules('name','name','required|is_unique[subcategories.name]',
      array('required'=>'you must provide subcategory %s',
            'is_unique'=>'subcategory exists'));
    if ($this->form_validation->run()==FALSE) {
      $this->load->view('subcategories/insert');
      //redirect(base_url('subcategories/add_form'));
    }
    else{
      //$this->load->view ('subcategories/show_subcategories', $data);
      $data['category_id'] = $this->input->post('category_id');
      $data['name'] = $this->input->post('name');
      $res = $this->Subcategory_model->insert_subcategory_to_table($data);
      redirect(base_url('subcategories'));
    }
  }

  function validate_dropdown($data){
    if ($data=="none") {
      $this->form_validation->set_message('validate_dropdown', 'Please Select Your Category.');
      return FALSE;
    }
    else{
      return TRUE;

    }
  }


  public function edit($id){
    $subcategory = $this->Subcategory_model->find_subcategory($id);
    $this->load->view('subcategories/edit',array('subcategory' => $subcategory));
  }


  public function update($id){
     $subcategory = $this->Subcategory_model->find_subcategory($id);
    $this->form_validation->set_rules('name', 'Name', 'required|is_unique[subcategories.name]');
      //,array('is_unique[subcategories.name]' => 'Error Message category exists'));
    if ($this->form_validation->run() == FALSE) {
      //$this->form_validation->set_message('update', 'Record already exists');
      $this->load->view('subcategories/edit',array('subcategory' => $subcategory));
      //redirect(base_url('subcategories'));
      //return FALSE;
    }
    else{
      $this->Subcategory_model->update_subcategory($id);
    redirect(base_url('subcategories'));
    }
    
  } 
/*
  public function update($id){
    $this->form_validation->set_rules('name','name','required|callback_validate_subcategory');
    if ($this->form_validation->run()==FALSE) {
      $this->load->view('subcategories/insert');
      return FALSE;
    }
    else{
      return TRUE;
    }


  }*/

  public function delete($id){
  $this->Subcategory_model->delete_subcategory($id);
  $this->index();
  }
}
?>